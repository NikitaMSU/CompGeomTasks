#pragma once
#include <QWidget>

class Task12Widget : public QWidget {
    Q_OBJECT
public:
    explicit Task12Widget(QWidget* parent = nullptr) : QWidget(parent) {}
};


