#pragma once
#include <QWidget>
#include <QLabel>

class Task04Widget : public QWidget {
    Q_OBJECT
public:
    explicit Task04Widget(QWidget* parent = nullptr) : QWidget(parent) {}
};


