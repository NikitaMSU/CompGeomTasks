#include "MainWindow.h"
#include "DrawingWidget.h"

#include <QLabel>
#include <QVBoxLayout>
#include <QToolBar>
#include <QAction>
#include <QStatusBar>
#include <QWidget>
#include <QPushButton>
#include <QHBoxLayout>

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
    , m_infoLabel(new QLabel(this))
    , m_statusLabel(new QLabel(this))
    , m_drawingWidget(new DrawingWidget(this))
    , m_toggleHullBtn(new QPushButton(tr("Показать оболочку"), this))
{
    auto* central = new QWidget(this);
    auto* mainLayout = new QVBoxLayout(central);
    mainLayout->setContentsMargins(6, 6, 6, 6);
    mainLayout->setSpacing(6);

    m_infoLabel->setText(tr("Чтобы добавить точку, нажмите левую кнопку мыши.\n Путем зажатия по точке и движения мыши осуществляется перенос точки (онлайн-перестроение оболочки).\n Кнопка 'Показать оболочку' — построить/скрыть выпуклую оболочку."));
    mainLayout->addWidget(m_infoLabel);

    auto* controlsLayout = new QHBoxLayout();
    controlsLayout->addWidget(m_toggleHullBtn);
    controlsLayout->addStretch(1);
    controlsLayout->addWidget(new QLabel(tr("Статистика:"), this));
    controlsLayout->addWidget(m_statusLabel);
    mainLayout->addLayout(controlsLayout);

    mainLayout->addWidget(m_drawingWidget, 1);

    setCentralWidget(central);

    auto* toolbar = addToolBar(tr("Инструменты"));
    auto* resetAction = toolbar->addAction(tr("Сброс"));
    connect(resetAction, &QAction::triggered, m_drawingWidget, &DrawingWidget::reset);

    statusBar()->showMessage(tr("Готово"));

    connect(m_drawingWidget, &DrawingWidget::hullChanged,
            this, &MainWindow::onHullUpdated);

    connect(m_toggleHullBtn, &QPushButton::clicked,
            this, &MainWindow::onToggleHull);

    setWindowTitle(tr("Выпуклая оболочка (Задача 5)"));
}

void MainWindow::onHullUpdated(std::size_t pointCount, std::size_t hullCount)
{
    m_statusLabel->setText(
        tr("точек: %1, на оболочке: %2")
        .arg(static_cast<qlonglong>(pointCount))
        .arg(static_cast<qlonglong>(hullCount))
    );
}

void MainWindow::onToggleHull()
{
    m_hullVisible = !m_hullVisible;
    if (m_hullVisible) {
        m_toggleHullBtn->setText(tr("Скрыть оболочку"));
    } else {
        m_toggleHullBtn->setText(tr("Показать оболочку"));
    }
    m_drawingWidget->setHullVisible(m_hullVisible);
}
