#pragma once

#include <QMainWindow>

class QLabel;
class QPushButton;
class DrawingWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);

private slots:
    void onHullUpdated(std::size_t pointCount, std::size_t hullCount);
    void onToggleHull();

private:
    QLabel*        m_infoLabel;
    QLabel*        m_statusLabel;
    DrawingWidget* m_drawingWidget;
    QPushButton*   m_toggleHullBtn;
    bool           m_hullVisible = false;
};
