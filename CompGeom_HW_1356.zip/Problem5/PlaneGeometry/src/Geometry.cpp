#include "PlaneGeometry/Geometry.h"
#include <algorithm>
#include <cmath>

namespace PlaneGeometry {

Real orient2d(const Point2D& a, const Point2D& b, const Point2D& c)
{
    // Вектор AB = (b.x - a.x, b.y - a.y)
    // Вектор AC = (c.x - a.x, c.y - a.y)
    // det = AB.x * AC.y - AB.y * AC.x
    return (b.x - a.x) * (c.y - a.y) -
           (b.y - a.y) * (c.x - a.x);
}

namespace {
    constexpr Real EPS = static_cast<Real>(1e-18L);

    bool realLess(Real a, Real b)
    {
        return a + EPS < b;
    }

    bool realEqual(Real a, Real b)
    {
        return std::abs(a - b) <= EPS;
    }
}

std::vector<Point2D> convexHull(const std::vector<Point2D>& points)
{
    if (points.empty())
        return {};

    // Копируем точки и сортируем по x, при равенстве — по y
    std::vector<Point2D> pts = points;
    std::sort(pts.begin(), pts.end(), [](const Point2D& p1, const Point2D& p2) {
        if (!realEqual(p1.x, p2.x))
            return realLess(p1.x, p2.x);
        return realLess(p1.y, p2.y);
    });

    // Удаляем дубликаты (по x и y)
    pts.erase(std::unique(pts.begin(), pts.end(), [](const Point2D& p1, const Point2D& p2){
        return realEqual(p1.x, p2.x) && realEqual(p1.y, p2.y);
    }), pts.end());

    if (pts.size() <= 2)
        return pts;

    // Алгоритм монотонной цепи Эндрю:
    std::vector<Point2D> lower;
    lower.reserve(pts.size());
    for (const auto& p : pts) {
        while (lower.size() >= 2) {
            const auto& q1 = lower[lower.size() - 2];
            const auto& q2 = lower[lower.size() - 1];
            Real cross = orient2d(q1, q2, p);
            // Убираем не-левые повороты (<= 0) для строгой оболочки
            if (cross > EPS)
                break;
            lower.pop_back();
        }
        lower.push_back(p);
    }

    std::vector<Point2D> upper;
    upper.reserve(pts.size());
    for (int i = static_cast<int>(pts.size()) - 1; i >= 0; --i) {
        const auto& p = pts[i];
        while (upper.size() >= 2) {
            const auto& q1 = upper[upper.size() - 2];
            const auto& q2 = upper[upper.size() - 1];
            Real cross = orient2d(q1, q2, p);
            if (cross > EPS)
                break;
            upper.pop_back();
        }
        upper.push_back(p);
    }

    // Последняя точка каждого списка — начальная точка другого, её дублировать не нужно
    lower.pop_back();
    upper.pop_back();

    std::vector<Point2D> hull;
    hull.reserve(lower.size() + upper.size());
    hull.insert(hull.end(), lower.begin(), lower.end());
    hull.insert(hull.end(), upper.begin(), upper.end());

    return hull;
}

} // namespace PlaneGeometry
