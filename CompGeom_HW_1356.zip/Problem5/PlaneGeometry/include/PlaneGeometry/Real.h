#pragma once

namespace PlaneGeometry {

// Тип для вычислений (повышенная точность по сравнению с double)
using Real = long double;

} // namespace PlaneGeometry
