#pragma once

#include <vector>
#include "Point2D.h"

namespace PlaneGeometry {

/// \brief Построение выпуклой оболочки множества точек (2D).
///
/// Используется алгоритм монотонной цепи Эндрю (Andrew's monotone chain).
/// На вход подаётся произвольный набор точек.
/// На выходе — точки оболочки в порядке обхода против часовой стрелки,
/// без повторения первой/последней точки.
/// При количестве точек < 3 возвращается копия исходного множества (после
/// удаления дубликатов).
std::vector<Point2D> convexHull(const std::vector<Point2D>& points);

/// Вспомогательная функция ориентации тройки точек (A, B, C).
/// > 0  — поворот влево,
/// < 0  — поворот вправо,
/// == 0 — коллинеарны.
Real orient2d(const Point2D& a, const Point2D& b, const Point2D& c);

} // namespace PlaneGeometry
