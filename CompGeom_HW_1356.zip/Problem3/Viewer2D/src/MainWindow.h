#pragma once

#include <QMainWindow>
#include "PlaneGeometry/Point2D.h"

class QLabel;
class QLineEdit;
class QPushButton;
class DrawingWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);

private slots:
    void onClassificationChanged(int orientation, bool hasSegment, bool pointOnSegment);
    void applyInputPoints();

private:
    QLabel*      m_infoLabel;
    QLabel*      m_resultLabel;
    DrawingWidget* m_drawingWidget;

    QLineEdit* m_axEdit;
    QLineEdit* m_ayEdit;
    QLineEdit* m_bxEdit;
    QLineEdit* m_byEdit;
    QLineEdit* m_pxEdit;
    QLineEdit* m_pyEdit;

    PlaneGeometry::Point2D parsePoint(const QString& xStr, const QString& yStr, bool& ok) const;
};
