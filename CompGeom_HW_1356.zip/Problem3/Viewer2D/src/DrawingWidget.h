#pragma once

#include <QWidget>
#include <optional>
#include "PlaneGeometry/Point2D.h"

class DrawingWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DrawingWidget(QWidget* parent = nullptr);

    QSize minimumSizeHint() const override;
    QSize sizeHint() const override;

public slots:
    void reset();

    /// Установка точек А, B, P из виджета ввода (текстовых полей)
    void setPointsFromInput(const PlaneGeometry::Point2D& a,
                            const PlaneGeometry::Point2D& b,
                            const PlaneGeometry::Point2D& p);

signals:
    /// orientation: 1 (слева), -1 (справа), 0 (коллинеарна)
    /// hasSegment: задан ли отрезок
    /// pointOnSegment: принадлежит ли точка самому отрезку
    void classificationChanged(int orientation, bool hasSegment, bool pointOnSegment);

protected:
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;

private:
    std::optional<PlaneGeometry::Point2D> m_a;
    std::optional<PlaneGeometry::Point2D> m_b;
    std::optional<PlaneGeometry::Point2D> m_p;

    int  m_orientation = 0;
    bool m_pointOnSegment = false;

    void updateClassification();
};
