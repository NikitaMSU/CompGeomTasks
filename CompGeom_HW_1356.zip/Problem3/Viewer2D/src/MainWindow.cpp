#include "MainWindow.h"
#include "DrawingWidget.h"

#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QToolBar>
#include <QAction>
#include <QStatusBar>
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QGroupBox>
#include <QMessageBox>

#include <string>

#include "PlaneGeometry/Real.h"
#include "PlaneGeometry/Geometry.h"

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
    , m_infoLabel(new QLabel(this))
    , m_resultLabel(new QLabel(this))
    , m_drawingWidget(new DrawingWidget(this))
{
    auto* central = new QWidget(this);
    auto* mainLayout = new QVBoxLayout(central);
    mainLayout->setContentsMargins(6, 6, 6, 6);
    mainLayout->setSpacing(6);

    m_infoLabel->setText(tr(
        "Задайте две точки отрезка A и B, затем точку P.\n"
        "Ниже можно ввести координаты A, B, P вручную с высокой точностью или задать точки нажатием левой кнопки мыши.\n"
        "Результат отображается в статус-баре и в поле 'Результат'."
    ));
    mainLayout->addWidget(m_infoLabel);

    // Панель ввода координат
    auto* inputGroup = new QGroupBox(tr("Ввод координат A, B и P"), this);
    auto* gLayout = new QGridLayout(inputGroup);

    m_axEdit = new QLineEdit(inputGroup);
    m_ayEdit = new QLineEdit(inputGroup);
    m_bxEdit = new QLineEdit(inputGroup);
    m_byEdit = new QLineEdit(inputGroup);
    m_pxEdit = new QLineEdit(inputGroup);
    m_pyEdit = new QLineEdit(inputGroup);

    m_axEdit->setPlaceholderText("A.x");
    m_ayEdit->setPlaceholderText("A.y");
    m_bxEdit->setPlaceholderText("B.x");
    m_byEdit->setPlaceholderText("B.y");
    m_pxEdit->setPlaceholderText("P.x");
    m_pyEdit->setPlaceholderText("P.y");

    int row = 0;
    gLayout->addWidget(new QLabel("A (x, y):"), row, 0);
    gLayout->addWidget(m_axEdit, row, 1);
    gLayout->addWidget(m_ayEdit, row, 2);

    row++;
    gLayout->addWidget(new QLabel("B (x, y):"), row, 0);
    gLayout->addWidget(m_bxEdit, row, 1);
    gLayout->addWidget(m_byEdit, row, 2);

    row++;
    gLayout->addWidget(new QLabel("P (x, y):"), row, 0);
    gLayout->addWidget(m_pxEdit, row, 1);
    gLayout->addWidget(m_pyEdit, row, 2);

    auto* applyBtn = new QPushButton(tr("Применить точки"), inputGroup);
    row++;
    gLayout->addWidget(applyBtn, row, 0, 1, 3);

    inputGroup->setLayout(gLayout);
    mainLayout->addWidget(inputGroup);

    // Результат
    auto* resLayout = new QHBoxLayout();
    resLayout->addWidget(new QLabel(tr("Результат (1 / -1 / 0):"), this));
    m_resultLabel->setText("—");
    resLayout->addWidget(m_resultLabel);
    resLayout->addStretch(1);
    mainLayout->addLayout(resLayout);

    // Холст
    mainLayout->addWidget(m_drawingWidget, 1);

    setCentralWidget(central);

    // Toolbar
    auto* toolbar = addToolBar(tr("Инструменты"));
    auto* resetAction = toolbar->addAction(tr("Сброс"));
    connect(resetAction, &QAction::triggered, m_drawingWidget, &DrawingWidget::reset);

    statusBar()->showMessage(tr("Готово"));

    connect(m_drawingWidget, &DrawingWidget::classificationChanged,
            this, &MainWindow::onClassificationChanged);

    connect(applyBtn, &QPushButton::clicked,
            this, &MainWindow::applyInputPoints);

    setWindowTitle(tr("Предикат поворота (Задачи 1, 3)"));
}

PlaneGeometry::Point2D MainWindow::parsePoint(const QString& xStr,
                                              const QString& yStr,
                                              bool& ok) const
{
    ok = true;
    PlaneGeometry::Point2D p{0,0};

    try {
        // Используем std::stold для высокой точности (long double)
        std::string xs = xStr.trimmed().toStdString();
        std::string ys = yStr.trimmed().toStdString();

        if (!xs.empty())
            p.x = static_cast<PlaneGeometry::Real>(std::stold(xs));
        else
            ok = false;

        if (!ys.empty())
            p.y = static_cast<PlaneGeometry::Real>(std::stold(ys));
        else
            ok = false;
    } catch (...) {
        ok = false;
    }

    return p;
}

void MainWindow::applyInputPoints()
{
    bool okA = false, okB = false, okP = false;
    auto A = parsePoint(m_axEdit->text(), m_ayEdit->text(), okA);
    auto B = parsePoint(m_bxEdit->text(), m_byEdit->text(), okB);
    auto P = parsePoint(m_pxEdit->text(), m_pyEdit->text(), okP);

    if (!okA || !okB || !okP) {
        QMessageBox::warning(this, tr("Ошибка ввода"),
                             tr("Не удалось корректно разобрать координаты.Проверьте формат чисел (используйте точку как разделитель)."));
        return;
    }

    // Передаём в холст и пересчитываем
    m_drawingWidget->setPointsFromInput(A, B, P);
}

void MainWindow::onClassificationChanged(int orientation, bool hasSegment, bool pointOnSegment)
{
    if (!hasSegment) {
        statusBar()->showMessage(tr("Сначала задайте отрезок двумя точками A и B."));
        m_resultLabel->setText("—");
        return;
    }

    QString status;
    QString resText;

    if (!pointOnSegment && orientation == 0) {
        // Коллинеарна, но вне отрезка
        status = tr("Точка коллинеарна прямой AB, но лежит вне отрезка.");
        resText = "0"; // по задаче всё равно интересует 0 как 'на прямой',
                       // если нужно строго 'на отрезке', можно поменять.
    } else if (orientation > 0) {
        status = tr("Результат: 1 (точка слева от направленного отрезка AB)");
        resText = "1";
    } else if (orientation < 0) {
        status = tr("Результат: -1 (точка справа от направленного отрезка AB)");
        resText = "-1";
    } else { // orientation == 0 && pointOnSegment
        status = tr("Результат: 0 (точка лежит на отрезке)");
        resText = "0";
    }

    statusBar()->showMessage(status);
    m_resultLabel->setText(resText);
}
