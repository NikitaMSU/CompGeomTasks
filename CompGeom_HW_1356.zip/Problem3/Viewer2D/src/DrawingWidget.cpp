#include "DrawingWidget.h"
#include "PlaneGeometry/Geometry.h"

#include <QMouseEvent>
#include <QPainter>
#include <QPen>
#include <QBrush>

DrawingWidget::DrawingWidget(QWidget* parent)
    : QWidget(parent)
{
    setAutoFillBackground(true);
    QPalette pal = palette();
    pal.setColor(QPalette::Window, QColor(250, 250, 250));
    setPalette(pal);
}

QSize DrawingWidget::minimumSizeHint() const
{
    return QSize(300, 300);
}

QSize DrawingWidget::sizeHint() const
{
    return QSize(700, 450);
}

void DrawingWidget::reset()
{
    m_a.reset();
    m_b.reset();
    m_p.reset();
    m_orientation = 0;
    m_pointOnSegment = false;
    update();
    emit classificationChanged(0, false, false);
}

void DrawingWidget::setPointsFromInput(const PlaneGeometry::Point2D& a,
                                       const PlaneGeometry::Point2D& b,
                                       const PlaneGeometry::Point2D& p)
{
    m_a = a;
    m_b = b;
    m_p = p;
    updateClassification();
    update();
}

void DrawingWidget::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);

    // Отрезок
    if (m_a && m_b) {
        painter.save();
        QPen segPen;
        segPen.setWidth(2);
        painter.setPen(segPen);
        painter.drawLine(
            QPointF(static_cast<double>(m_a->x), static_cast<double>(m_a->y)),
            QPointF(static_cast<double>(m_b->x), static_cast<double>(m_b->y))
        );
        painter.restore();

        // Концы отрезка
        painter.save();
        QBrush endpointBrush;
        endpointBrush.setStyle(Qt::SolidPattern);
        painter.setBrush(endpointBrush);
        painter.drawEllipse(
            QPointF(static_cast<double>(m_a->x), static_cast<double>(m_a->y)), 4, 4);
        painter.drawEllipse(
            QPointF(static_cast<double>(m_b->x), static_cast<double>(m_b->y)), 4, 4);
        painter.restore();
    }

    // Точка
    if (m_p) {
        painter.save();
        QBrush pointBrush;
        pointBrush.setStyle(Qt::SolidPattern);
        painter.setBrush(pointBrush);
        painter.setPen(Qt::NoPen);

        painter.drawEllipse(
            QPointF(static_cast<double>(m_p->x), static_cast<double>(m_p->y)), 5, 5);
        painter.restore();
    }
}

void DrawingWidget::mousePressEvent(QMouseEvent* event)
{
    if (event->button() != Qt::LeftButton)
        return;

#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
    QPointF pos = event->position();
#else
    QPointF pos = event->pos();
#endif

    PlaneGeometry::Point2D pt{
        static_cast<PlaneGeometry::Real>(pos.x()),
        static_cast<PlaneGeometry::Real>(pos.y())
    };

    if (!m_a) {
        m_a = pt;
    } else if (!m_b) {
        m_b = pt;
    } else {
        m_p = pt;
        updateClassification();
    }

    update();
}

void DrawingWidget::updateClassification()
{
    if (!(m_a && m_b && m_p)) {
        emit classificationChanged(0, false, false);
        return;
    }

    m_orientation   = PlaneGeometry::pointSegmentOrientation(*m_a, *m_b, *m_p);
    m_pointOnSegment = PlaneGeometry::isPointOnSegment(*m_a, *m_b, *m_p);

    emit classificationChanged(m_orientation, true, m_pointOnSegment);
}
