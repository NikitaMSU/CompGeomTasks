#include "PlaneGeometry/Geometry.h"
#include <algorithm>
#include <cmath>

namespace PlaneGeometry {

namespace {
    // Чуть более строгий EPS, т.к. используем long double
    constexpr Real EPS = static_cast<Real>(1e-18L);
}

int pointSegmentOrientation(const Point2D& a, const Point2D& b, const Point2D& p)
{
    const Real abx = b.x - a.x;
    const Real aby = b.y - a.y;
    const Real apx = p.x - a.x;
    const Real apy = p.y - a.y;

    const Real cross = abx * apy - aby * apx;

    if (cross > EPS)
        return 1;   // слева
    if (cross < -EPS)
        return -1;  // справа

    // Коллинеарный случай
    return 0;
}

bool isPointOnSegment(const Point2D& a, const Point2D& b, const Point2D& p)
{
    const Real minX = std::min(a.x, b.x) - EPS;
    const Real maxX = std::max(a.x, b.x) + EPS;
    const Real minY = std::min(a.y, b.y) - EPS;
    const Real maxY = std::max(a.y, b.y) + EPS;

    if (p.x < minX || p.x > maxX || p.y < minY || p.y > maxY)
        return false;

    // Дополнительно убеждаемся, что точка коллинеарна прямой AB:
    return pointSegmentOrientation(a, b, p) == 0;
}

} // namespace PlaneGeometry
