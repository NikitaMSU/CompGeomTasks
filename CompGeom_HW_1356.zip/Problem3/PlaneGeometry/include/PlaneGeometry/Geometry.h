#pragma once

#include "Point2D.h"

namespace PlaneGeometry {

/// \brief Возвращает положение точки относительно направленного отрезка AB.
/// \return  1  - точка слева от отрезка AB
///         -1  - точка справа от отрезка AB
///          0  - точка лежит на прямой AB (в том числе на отрезке)
int pointSegmentOrientation(const Point2D& a, const Point2D& b, const Point2D& p);

/// \brief Проверка, лежит ли точка p на самом отрезке AB (между концами).
/// Предполагается, что точка уже (почти) коллинеарна прямой AB.
bool isPointOnSegment(const Point2D& a, const Point2D& b, const Point2D& p);

} // namespace PlaneGeometry
