#pragma once

namespace PlaneGeometry {

// Тип для вычислений: long double даёт повышенную точность
using Real = long double;

} // namespace PlaneGeometry
