#pragma once
#include "Real.h"

namespace PlaneGeometry {

struct Point2D
{
    Real x;
    Real y;
};

} // namespace PlaneGeometry
